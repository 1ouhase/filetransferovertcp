package net.iouhase.kat2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kat2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
