package net.iouhase.kat2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kat2Application {

    public static void main(String[] args) {
        SpringApplication.run(Kat2Application.class, args);
    }

}